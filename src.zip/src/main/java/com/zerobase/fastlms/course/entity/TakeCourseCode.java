package com.zerobase.fastlms.course.entity;

public interface TakeCourseCode {
    
    String STATUS_REQ = "REQ";// 수강신청
    String STATUS_COMPLETE = "COMPLETE";//결재완료
    String STATUS_CANCEL = "CANCEL";//수강취소
   
}
