package com.zerobase.fastlms.admin.model;

import lombok.Data;

@Data
public class MemberParam extends CommonParam {
    
    String userId;
    
}
